<?php

namespace App\Http\Controllers;

use App\Models\Produk; // Pastikan nama model Anda adalah 'Produk'
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class ProdukController extends Controller
{
    /**
     * Menampilkan daftar produk dengan pagination.
     */
    public function index(): View
    {
        // PERBAIKAN: Menggunakan paginate() untuk mengambil data.
        // Angka 10 adalah jumlah item per halaman.
        $produks = Produk::latest()->paginate(10);

        // Mengirim data ke view
        return view('produk.index', compact('produks'));
    }

    /**
     * Menampilkan formulir untuk membuat produk baru.
     */
    public function create(): View
    {
        return view('produk.create');
    }

    /**
     * Menyimpan produk baru ke dalam database.
     */
    public function store(Request $request): RedirectResponse
    {
        // Validasi input
        $request->validate([
            'nama_produk' => 'required|string|max:255',
            'sku' => 'required|string|max:50|unique:produks',
            'kategori' => 'required|string|max:100',
            'jumlah' => 'required|integer|min:0',
            'harga_beli' => 'required|numeric|min:0',
            'supplier' => 'required|string|max:255',
        ]);

        // Membuat produk baru
        Produk::create($request->all());

        // Redirect ke halaman index dengan pesan sukses
        return redirect()->route('produk.index')
                         ->with('success', 'Produk baru berhasil ditambahkan.');
    }

    /**
     * Menampilkan formulir untuk mengedit produk.
     */
    public function edit(Produk $produk): View
    {
        return view('produk.edit', compact('produk'));
    }

    /**
     * Mengupdate data produk di database.
     */
    public function update(Request $request, Produk $produk): RedirectResponse
    {
        // Validasi input
        $request->validate([
            'nama_produk' => 'required|string|max:255',
            'sku' => 'required|string|max:50|unique:produks,sku,' . $produk->id,
            'kategori' => 'required|string|max:100',
            'jumlah' => 'required|integer|min:0',
            'harga_beli' => 'required|numeric|min:0',
            'supplier' => 'required|string|max:255',
        ]);

        // Update data produk
        $produk->update($request->all());

        // Redirect ke halaman index dengan pesan sukses
        return redirect()->route('produk.index')
                         ->with('success', 'Data produk berhasil diperbarui.');
    }

    /**
     * Menghapus produk dari database.
     */
    public function destroy(Produk $produk): RedirectResponse
    {
        // Hapus produk
        $produk->delete();

        // Redirect ke halaman index dengan pesan sukses
        return redirect()->route('produk.index')
                         ->with('success', 'Produk berhasil dihapus.');
    }
}
