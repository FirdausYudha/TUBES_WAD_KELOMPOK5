@extends('layout')
@section('title', 'Login')
@section('content')

<div class="container">
    <div class="card shadow-sm rounded-3 auth-card">
        <div class="card-body p-5">
            <div class="text-center mb-4">
                <i class="fa-solid fa-right-to-bracket fa-3x text-primary mb-3"></i>
                <h2 class="card-title fw-bold">Selamat Datang Kembali</h2>
                <p class="text-muted">Silakan login untuk melanjutkan</p>
            </div>

            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <form action="{{ route('login') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" id="email" class="form-control" required placeholder="nama@email.com">
                </div>
                <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" id="password" class="form-control" required placeholder="••••••••">
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-lg">Login</button>
                </div>
            </form>

            <p class="mt-4 text-center text-muted">Belum punya akun? <a href="{{ route('register') }}">Daftar di sini</a></p>
        </div>
    </div>
</div>
@endsection