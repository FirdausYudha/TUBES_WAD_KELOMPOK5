@extends('layout')
@section('title', 'Daftar Produk')
@section('content')
<div class="container">
    <div class="card shadow-sm rounded-3">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Daftar Produk</h3>
                <a href="{{ route('produk.create') }}" class="btn btn-primary">
                    <i class="fa-solid fa-plus me-1"></i> Tambah Produk
                </a>
            </div>
        </div>
        <div class="card-body">
            @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif

            <div class="table-responsive">
                <table class="table table-hover table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>
                            <th>Jumlah</th>
                            <th>Harga Beli</th>
                            <th>Supplier</th>
                            <th>SKU</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($produks as $index => $produk)
                        <tr>
                            <td>{{ $produks->firstItem() + $index }}</td>
                            <td>{{ $produk->nama_produk }}</td>
                            <td><span class="badge bg-secondary">{{ $produk->kategori }}</span></td>
                            <td>{{ $produk->jumlah }}</td>
                            <td>Rp {{ number_format($produk->harga_beli, 0, ',', '.') }}</td>
                            <td>{{ $produk->supplier }}</td>
                            <td>{{ $produk->sku }}</td>
                            <td class="text-center">
                                <form action="{{ route('produk.destroy', $produk->id) }}" method="POST" class="d-inline">
                                    <a href="{{ route('produk.edit', $produk->id) }}" class="btn btn-warning btn-sm" title="Edit">
                                        <i class="fa-solid fa-pencil"></i>
                                    </a>
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?')" title="Hapus">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="8" class="text-center text-muted">
                                Belum ada data produk. Silakan tambah produk baru.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination Links -->
            <div class="d-flex justify-content-center">
                {{ $produks->links() }}
            </div>
        </div>
    </div>
</div>
@endsection